import React from 'react';
import { Empty } from 'antd';
export default function NotFound() {
  return <Empty description={'页面不见了'} style={{ marginTop: '30vh' }} />;
}
