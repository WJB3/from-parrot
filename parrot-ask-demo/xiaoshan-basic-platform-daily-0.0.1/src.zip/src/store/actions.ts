export enum ActionType {
  LOGIN = "LOGIN",
  LOGINSUCCESS = "LOGINSUCCESS",
  GetUser = "GET_USER",
  SetBreadcrumb = "SET_BREADCRUMB",
  INIT = "INIT",
  AddSocketHandler = "AddSocketHandler",
  RemoveSockerHandler = "RemoveSockerHandler",
  UpdateTabId = "UpdateTabId",
}
