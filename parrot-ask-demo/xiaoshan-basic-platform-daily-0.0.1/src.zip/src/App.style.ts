import { CSSProperties } from 'react';

const table: CSSProperties = {
  background: '#fff',
};
const appStyle = {
  table,
};
export default appStyle;
