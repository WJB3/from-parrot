const role = {
  state: new Map([
    [1, '开启'],
    [0, '关闭'],
  ]),
};
export default role;
