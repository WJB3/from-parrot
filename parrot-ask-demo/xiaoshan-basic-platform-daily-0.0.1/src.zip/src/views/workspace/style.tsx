import { CSSProperties } from 'react';

export const container: CSSProperties = {
  width: 1200,
  margin: '0 auto',
  marginTop: 20,
};
