import React from "react";
import { createFromIconfontCN } from "@ant-design/icons";
const IconFont = createFromIconfontCN({
  scriptUrl: "//at.alicdn.com/t/font_2042461_n72cjf7vzz.js",
});
export default IconFont;
