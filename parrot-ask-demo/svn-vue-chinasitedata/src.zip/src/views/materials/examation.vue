<template>
    <div>
齐套性检查（阻焊）
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style lang="scss" scoped>

</style>