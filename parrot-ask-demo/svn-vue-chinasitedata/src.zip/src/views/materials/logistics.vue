<template>
    <div>
物流
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style lang="scss" scoped>

</style>