<template>
    <div>
在制品
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style lang="scss" scoped>

</style>