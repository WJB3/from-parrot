<template>
    <div>
产品Bom管理
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style lang="scss" scoped>

</style>