<template>
    <div>
     齐套性检查
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style lang="scss" scoped>

</style>