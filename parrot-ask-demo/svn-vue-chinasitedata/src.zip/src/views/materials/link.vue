<template>
    <div>
    物流实时状态监控
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style lang="scss" scoped>

</style>