<template>
    <div>
    物料状态查询
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style lang="scss" scoped>

</style>