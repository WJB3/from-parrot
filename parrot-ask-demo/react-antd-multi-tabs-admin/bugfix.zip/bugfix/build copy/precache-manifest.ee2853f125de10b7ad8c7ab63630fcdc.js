self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "07b97c66a23c5316f79a1f02bca4428e",
    "url": "./index.html"
  },
  {
    "revision": "315537924a8ac4db5633",
    "url": "./static/css/main.c9a55e46.css"
  },
  {
    "revision": "94db96b78046884b52f0",
    "url": "./static/css/vendors~main.6eab225b.chunk.css"
  },
  {
    "revision": "315537924a8ac4db5633",
    "url": "./static/js/main.544726f9.js"
  },
  {
    "revision": "94db96b78046884b52f0",
    "url": "./static/js/vendors~main.c3ea34c9.chunk.js"
  },
  {
    "revision": "5825f033c6ff12cd1ed1f3c99dff5e4b",
    "url": "./static/media/login-bg.5825f033.svg"
  },
  {
    "revision": "4f91ce715b866a4dcae28e244be36c34",
    "url": "./static/media/newlogo.4f91ce71.png"
  }
]);